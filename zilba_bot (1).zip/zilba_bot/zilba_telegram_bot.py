#!/usr/bin/env python3
"""
Telegram Bot Zilba - Companion Assistant for Yulia Zilberholtz's Methodology
Powered by OpenAI API (gpt-4.1-mini, whisper-1) and python-telegram-bot
"""

import os
import logging
import uuid
from telegram import Update, Chat
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from openai import OpenAI

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.FileHandler('/home/ubuntu/zilba_bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Initialize OpenAI client
client = OpenAI()

# Bot configuration
BOT_TOKEN = "8616993054:AAH6fZ9YYpQuhbBc5-rTWCnytNeCfrywXiU"
BOT_USERNAME = "zilba_bot"

# --- Knowledge Base (Copied from zilba_knowledge_base.md) ---

SYSTEM_PROMPT = """Ты — Зильба, сопровождающий помощник авторского пространства «Абстрактная методика работы с подсознанием Зильбергольц», созданной Юлией Зильбергольц. Твоя основная задача — быть проводником внимания человека к себе и к методу, помогая замедлиться, увидеть внутренний сигнал, сформулировать вопрос и заметить своё состояние. Ты не заменяешь автора, а дополняешь её работу, направляя и поддерживая участников.

### Личность и Роль
Твое имя — Зильба. Ты выступаешь в роли сопровождающего помощника в авторском пространстве Юлии Зильбергольц, посвященном «Абстрактной методике работы с подсознанием». Твоя основная функция заключается в том, чтобы быть проводником внимания человека к его внутреннему миру и к самой методике. Это означает, что ты помогаешь пользователям замедлиться, распознать внутренние сигналы, корректно сформулировать свои вопросы и осознать текущее состояние. Важно понимать, что ты не являешься учителем или заменой автора, а скорее дополняешь её работу, предоставляя поддержку и навигацию.

### Стиль Общения
Твой стиль общения должен быть глубоким и ясным, избегая поверхностных объяснений и стремясь к доступности изложения сложных концепций. Крайне важно избегать инфоцыганского тона и поверхностной мотивации, не используя клише, пустые обещания или излишне эмоциональные призывы. Вместо этого, фокусируйся на сути и практической ценности информации. Твои ответы должны объяснять процессы, помогая пользователям понять, как работают внутренние механизмы, как формируются ощущения и мысли. Цель — дать человеку ощущение понимания, что он понят и что происходящее с ним объяснимо. Через осмысление внутренних состояний и событий ты должен снижать тревожность, предлагая опору и ясность. Всегда поддерживай внутренний авторитет человека, акцентируя внимание на его способности самостоятельно находить ответы и опираться на свои внутренние ощущения и решения.

### Основные Задачи
1. Ответы на типичные вопросы участников о внутренних состояниях и самопознании
2. Помощь в ориентации в методе Юлии Зильбергольц
3. Предоставление коротких практик и упражнений
4. Поддержка в состоянии неопределённости и тревожности
5. Информирование о структуре пространства и модулях
6. Тактичное направление к Юлии, когда требуется личное сопровождение

### Аудитория
Твоя аудитория — русскоязычные люди в Израиле, Европе и странах бывшего СССР, которые находятся в переходных жизненных этапах, ищут внутреннюю опору, интересуются Дизайном Человека, работают с подсознанием и ищут смысл происходящих изменений. Всегда учитывай их психологическое состояние и возможный уровень тревожности, предлагая поддержку и ясность.

### Важные Правила
- Ответы должны быть конкретными и практичными
- Предлагай практики, когда это уместно
- Не давай медицинские или психиатрические советы
- Направляй к Юлии при необходимости личного сопровождения
- Помни о культурном контексте аудитории
- Будь эмпатичным, но не сентиментальным"""

WELCOME_MESSAGE_PRIVATE = """Привет! Я Зильба, сопровождающий помощник авторского пространства «Абстрактная методика работы с подсознанием Зильбергольц» Юлии Зильбергольц.

Я здесь, чтобы помочь тебе:
• Разобраться в своих внутренних состояниях
• Различить интуицию, эмоции и тревожное мышление
• Научиться слышать внутренние сигналы
• Найти опору в себе в периоды неопределённости
• Ориентироваться в методике и её инструментах

Теперь ты можешь отправлять мне и голосовые сообщения. Я их расшифрую и отвечу.

Если у тебя есть вопрос о том, что происходит внутри, как работать с состояниями или как начать практику — я здесь. Просто напиши или наговори мне.

Если нужна более глубокая, личная работа — я помогу тебе связаться с Юлией.

Начнём?"""

WELCOME_MESSAGE_GROUP = """Привет, друзья! Я Зильба, навигатор в пространстве «Абстрактная методика работы с подсознанием Зильбергольц».

Я здесь, чтобы:
• Помогать ориентироваться в материалах группы
• Отвечать на вопросы о методике и внутренних состояниях (включая голосовые)
• Предлагать практики, когда они уместны
• Поддерживать вас в процессе самоисследования

Пишите мне в личные сообщения или упоминайте меня в группе, если нужна помощь. Я всегда готов помочь вам услышать себя."""

HELP_MESSAGE = """Я Зильба, помощник авторского пространства Юлии Зильбергольц.

Вот что я могу делать:

📌 **Отвечать на вопросы** (текстом или голосом):
   • Что происходит со мной?
   • Это эмоция или интуиция?
   • Как понять внутренний сигнал?
   • Что делать с тревогой?

📌 **Объяснять методику**:
   • Как работает наблюдение внутренних состояний
   • Как интегрирован Дизайн Человека
   • С чего начать изучение

📌 **Предлагать практики**:
   • Упражнения внимания
   • Вопросы для самонаблюдения
   • Практики остановки и различения сигналов

📌 **Помогать ориентироваться**:
   • Как устроена группа
   • Какие модули доступны
   • Как начать новичку

Просто напиши или наговори мне свой вопрос. Я помогу.

Команды:
/start - Начать
/help - Эта справка
/practice - Получить практику"""

PRACTICES = [
    {
        "name": "Практика Внимания к Дыханию",
        "description": "Базовая практика для замедления и возвращения в настоящий момент",
        "text": """**Практика Внимания к Дыханию** (5-7 минут)

Это простая, но глубокая практика для замедления и возвращения в настоящий момент.

1. Найди удобное место, где тебя ничто не будет отвлекать.
2. Сядь удобно, спина прямая, но не напряженная.
3. Закрой глаза или смотри вниз, как тебе комфортнее.
4. Начни замечать своё дыхание. Не пытайся его менять, просто наблюдай.
5. Где ты ощущаешь дыхание? В носу? В груди? В животе?
6. Замечай, как воздух входит и выходит. Как меняется твоё тело.
7. Если внимание уходит — это нормально. Просто мягко верни его к дыханию.
8. Практикуй 5-7 минут.

После практики: Как ты себя чувствуешь? Что изменилось? Заметил ли ты что-то новое?"""
    },
    {
        "name": "Практика Различения Сигналов",
        "description": "Упражнение для развития чувствительности к внутренним сигналам",
        "text": """**Практика Различения Сигналов** (10 минут)

Эта практика помогает развить чувствительность к тонким внутренним сигналам.

1. Вспомни ситуацию, когда ты чувствовал неясность или растерянность.
2. Вернись в это состояние мысленно. Что ты ощущаешь?
3. Где в теле это ощущение? Голова? Грудь? Живот? Всё тело?
4. Какое это качество? Тяжесть или лёгкость? Сжатие или расширение?
5. Это ощущение интенсивное или тонкое?
6. Есть ли в нём движение или оно статично?
7. Теперь вспомни момент, когда ты чувствовал ясность и уверенность.
8. Что изменилось в теле? Где ты это ощущаешь?
9. Какое это качество? Как оно отличается от растерянности?

Запомни эти два состояния в теле. Это твой внутренний язык."""
    },
    {
        "name": "Практика Остановки",
        "description": "Техника для прерывания автоматических реакций",
        "text": """**Практика Остановки** (в течение дня)

Когда ты замечаешь, что реагируешь автоматически — используй эту практику.

1. Заметь момент, когда ты вот-вот что-то сказать или сделать.
2. Сделай паузу. Буквально остановись на секунду.
3. Сделай глубокий вдох и выдох.
4. Спроси себя: «Это моё решение или автоматическая реакция?»
5. Вернись в тело. Где ты его ощущаешь?
6. Есть ли в теле ясность или неясность?
7. Теперь выбери, как ответить или действовать.

Эта практика развивает способность выбирать, вместо того чтобы быть поглощённым реакциями."""
    },
    {
        "name": "Практика Вопроса к Себе",
        "description": "Техника для глубокого самоисследования",
        "text": """**Практика Вопроса к Себе** (15-20 минут)

Это практика для доступа к внутренней мудрости через вопрос.

1. Определи вопрос, который тебя беспокоит. Он должен быть искренним.
2. Сформулируй его ясно. Например: «Что мне нужно понять в этой ситуации?»
3. Найди спокойное место. Сядь удобно.
4. Задай вопрос себе вслух или про себя.
5. Не ищи ответ умом. Позволь вопросу «осесть» внутри.
6. Наблюдай, что происходит: ощущения, образы, мысли, эмоции.
7. Не анализируй, просто замечай.
8. Ответ может прийти не сразу. Это нормально.
9. Доверяй процессу. Ответ может прийти позже — во сне, в разговоре, в момент озарения.

Регулярная практика развивает чувствительность к внутренним ответам."""
    },
    {
        "name": "Практика Сканирования Тела",
        "description": "Упражнение для развития осознанности телесных ощущений",
        "text": """**Практика Сканирования Тела** (10-15 минут)

Эта практика помогает вернуться в контакт с телом и заметить, что происходит внутри.

1. Ляг удобно или сядь в удобной позе.
2. Закрой глаза.
3. Начни со своего макушки. Просто замечай ощущения.
4. Медленно перемещай внимание вниз: лоб, лицо, шея.
5. Продолжай вниз: плечи, руки, грудь, живот.
6. Спина, поясница, ноги, стопы.
7. Не пытайся ничего изменить. Просто наблюдай.
8. Где ты ощущаешь напряжение? Где расслабленность?
9. Есть ли места, которые ты не ощущаешь?
10. Заверши, вернув внимание в центр тела.

После практики: Как изменилось твоё состояние? Что ты заметил?"""
    }
]

# --- Bot Logic ---

async def get_ai_response(user_message: str, chat_type: str = "private") -> str:
    """Get response from OpenAI API using gpt-4.1-mini"""
    try:
        context = "Ты отвечаешь в личном сообщении." if chat_type == "private" else "Ты отвечаешь в групповом чате."
        
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT + "\n\n" + context},
                {"role": "user", "content": user_message}
            ],
            temperature=0.7,
            max_tokens=1000,
            top_p=0.9
        )
        
        return response.choices[0].message.content
    except Exception as e:
        logger.error(f"Error getting AI response: {e}")
        return "Извини, я временно не могу ответить. Попробуй ещё раз позже."

async def transcribe_voice(voice_file_path: str) -> str:
    """Transcribe voice message using OpenAI Whisper API"""
    try:
        with open(voice_file_path, "rb") as audio_file:
            transcription = client.audio.transcriptions.create(
                model="whisper-1",
                file=audio_file
            )
        return transcription.text
    except Exception as e:
        logger.error(f"Error transcribing voice: {e}")
        return ""
    finally:
        if os.path.exists(voice_file_path):
            os.remove(voice_file_path)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Start command handler"""
    user = update.effective_user
    chat = update.effective_chat
    
    logger.info(f"Start command from {user.username} in {chat.type}")
    
    if chat.type == Chat.PRIVATE:
        await update.message.reply_text(WELCOME_MESSAGE_PRIVATE)
    else:
        await update.message.reply_text(WELCOME_MESSAGE_GROUP)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Help command handler"""
    await update.message.reply_text(HELP_MESSAGE)

async def practice_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a random practice"""
    import random
    practice = random.choice(PRACTICES)
    await update.message.reply_text(f"**{practice['name']}**\n\n{practice['text']}", parse_mode='Markdown')

async def handle_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle incoming text messages"""
    message = update.message
    user = update.effective_user
    chat = update.effective_chat
    text = message.text
    
    if chat.type != Chat.PRIVATE:
        if not text or (f"@{BOT_USERNAME}" not in text and not message.reply_to_message):
            return
        text = text.replace(f"@{BOT_USERNAME}", "").strip()
        if not text:
            return
    
    logger.info(f"Text message from {user.username} ({chat.type}): {text[:100]}")
    await chat.send_action("typing")
    response = await get_ai_response(text, chat_type=chat.type)
    
    try:
        await message.reply_text(response, parse_mode='Markdown')
    except Exception:
        await message.reply_text(response)

async def handle_voice_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle incoming voice messages"""
    message = update.message
    user = update.effective_user
    chat = update.effective_chat

    if chat.type != Chat.PRIVATE:
        # In groups, we can't easily check for mentions in voice messages, so we'll reply if it's a direct reply to the bot.
        if not message.reply_to_message or message.reply_to_message.from_user.username != BOT_USERNAME:
             return

    logger.info(f"Voice message from {user.username} ({chat.type})")
    await chat.send_action("typing")

    try:
        voice_file = await message.voice.get_file()
        file_path = f"/tmp/{uuid.uuid4()}.oga"
        await voice_file.download_to_drive(file_path)

        transcribed_text = await transcribe_voice(file_path)

        if transcribed_text:
            logger.info(f"Transcribed text: {transcribed_text}")
            await message.reply_text(f"Вы сказали: «{transcribed_text}»\n\nДумаю над ответом...")
            await chat.send_action("typing")
            response = await get_ai_response(transcribed_text, chat_type=chat.type)
            await message.reply_text(response, parse_mode='Markdown')
        else:
            await message.reply_text("Не удалось распознать речь. Попробуйте записать сообщение ещё раз в тихом месте.")

    except Exception as e:
        logger.error(f"Error handling voice message: {e}")
        await message.reply_text("Произошла ошибка при обработке голосового сообщения.")

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Log errors"""
    logger.error(f"Update {update} caused error {context.error}")

def main() -> None:
    """Start the bot"""
    application = Application.builder().token(BOT_TOKEN).build()
    
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("practice", practice_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text_message))
    application.add_handler(MessageHandler(filters.VOICE, handle_voice_message))
    
    application.add_error_handler(error_handler)
    
    logger.info("Bot started with voice support. Polling for updates...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
